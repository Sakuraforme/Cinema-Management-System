package com.moke.wp.wx_weimai.config.shiro;

import org.apache.shiro.authc.UsernamePasswordToken;

import java.io.Serializable;

public class AdminToken extends UsernamePasswordToken implements Serializable {


}
